package ui.component;

import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

public class SubTitle extends Text {
	public SubTitle(String txt) {
		super(txt);
		setStyle("-fx-color: #FF2D00;");
		setFont(Font.font("Harlow Solid Italic", FontWeight.BOLD, 16));		
	}
	
}

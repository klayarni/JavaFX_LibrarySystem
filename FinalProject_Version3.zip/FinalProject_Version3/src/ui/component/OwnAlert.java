package ui.component;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;

public class OwnAlert extends Alert {
	public OwnAlert(AlertType type) {
		super(type);
	}
	
	public OwnAlert(AlertType type, String header, String content) {
		super(type);
		setHeaderText(header);
		setContentText(content);
	}

	public OwnAlert(AlertType type, String header, String content, ButtonType buttonType) {
		super(type, content, buttonType);
		setHeaderText(header);
	}
}

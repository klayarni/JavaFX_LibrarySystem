package ui;

import java.util.Collections;
import java.util.List;

import business.ControllerInterface;
import business.LibraryMember;
import business.SystemController;
import dataaccess.Auth;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class Start extends Application {

	private static final Start INSTANCE = new Start();
/*create a singleton(one instance to run at any one time)*/	
	public static Start getInstance() {
		return INSTANCE;
	}

	private static Stage primStage = null;
/*create a new authorization level so as to work within this file*/
	private static Auth authLevel = Auth.NONE;
/*updates the authorization level to check which authorization rights to give a user who logs in*/
	public static void updateStage(Auth authLevel) {
		Start.authLevel = authLevel;
		INSTANCE.start(primStage);
	}

	public static void main(String[] args) {
		launch(args);
	}

	private static Stage[] allWindows = { LoginWindow.INSTANCE, AddMember.INSTANCE, AllBooksWindow.INSTANCE,
			MembersWindow.INSTANCE, LibrarianCheckoutWindow.INSTANCE };

	public static void LoginWindow() {
		hideAllWindows();
		if (!LoginWindow.INSTANCE.isInitialized()) {
			LoginWindow.INSTANCE.init();
		}
		LoginWindow.INSTANCE.show();
	}

	public static Stage primStage() {
		return primStage;
	}

	public static class Colors {
		static Color green = Color.web("#034220");
		static Color red = Color.FIREBRICK;
	}

	public static void hideAllWindows() {
		primStage.hide();
		for (Stage st : allWindows) {
			st.hide();
		}
	}

	// MEMBER START
	public static void showMembers(boolean refresh) {
		hideAllWindows();
		if (!MembersWindow.INSTANCE.isInitialized()) {

			MembersWindow.INSTANCE.init();
		}

		if (refresh) {
			ControllerInterface ci = new SystemController();
			List<LibraryMember> members = ci.allMembers();
			Collections.sort(members);
			MembersWindow.INSTANCE.setData(members);
		}

		MembersWindow.INSTANCE.clear();
		MembersWindow.INSTANCE.show();
	}
	/*ADD MEMBER*/
	public static void addMember() {
		hideAllWindows();
		if (!AddMember.INSTANCE.isInitialized()) {
			AddMember.INSTANCE.init();
		}
		AddMember.INSTANCE.clearFields();
		AddMember.INSTANCE.show();
		AddMember.INSTANCE.addMember();
	}

	//MEMBER END

	@Override
	public void start(Stage primaryStage) {
		Start.primStage = primaryStage;
		primaryStage.setTitle("Main Page");

		VBox topContainer = new VBox();
		topContainer.setId("top-container");
		MenuBar mainMenu = new MenuBar();
		VBox imageHolder = new VBox();
		Image image = new Image("ui/library.jpg", 400, 300, false, false);

		// simply displays in ImageView the image as is
		ImageView iv = new ImageView();
		iv.setImage(image);
		imageHolder.getChildren().add(iv);
		imageHolder.setAlignment(Pos.CENTER);
		HBox splashBox = new HBox();
		Label splashLabel = new Label("The Library System");
		splashLabel.setFont(Font.font("Trajan Pro", FontWeight.BOLD, 30));
		splashBox.getChildren().add(splashLabel);
		splashBox.setAlignment(Pos.CENTER);

		topContainer.getChildren().add(mainMenu);
		topContainer.getChildren().add(splashBox);
		topContainer.getChildren().add(imageHolder);

		Menu optionsMenu = new Menu("Options");		
		
		/*VIEW MEMBER LIST MENU ITEM*/
		MenuItem memberList = new MenuItem("All Member List");

		memberList.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				hideAllWindows();
				if (!MembersWindow.INSTANCE.isInitialized()) {
					MembersWindow.INSTANCE.init();
				}
				ControllerInterface ci = new SystemController();
				List<LibraryMember> data = ci.allMembers();
				Collections.sort(data);
				System.out.println("UI Member List---------" + data);
				MembersWindow.INSTANCE.setData(data);
				MembersWindow.INSTANCE.show();
			}
		});
		
		/*ADD MEMBER MENU ITEM*/
		MenuItem addmember = new MenuItem("Add Member");

		addmember.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				addMember();
			}
		});
		
		/*CHECKOUT MENU ITEM*/
		MenuItem checkout = new MenuItem("Checkout Book");

		checkout.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				hideAllWindows();
				if (!LibrarianCheckoutWindow.INSTANCE.isInitialized()) {
					LibrarianCheckoutWindow.INSTANCE.init();
				}
				LibrarianCheckoutWindow.INSTANCE.clear();
				LibrarianCheckoutWindow.INSTANCE.show();
			}
		});		
		/*LOGIN MENU ITEM*/
		MenuItem login = new MenuItem("Login");

		login.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				hideAllWindows();
				if (!LoginWindow.INSTANCE.isInitialized()) {
					LoginWindow.INSTANCE.init();
				}
				LoginWindow.INSTANCE.clear();
				LoginWindow.INSTANCE.show();
			}
		});
		
		/*ALL BOOK IDS MENU ITEM*/
		MenuItem bookIds = new MenuItem("All Book Ids");
		bookIds.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				hideAllWindows();
				if (!AllBooksWindow.INSTANCE.isInitialized()) {
					AllBooksWindow.INSTANCE.init();
				}
				ControllerInterface ci = new SystemController();
				List<String> ids = ci.allBookIds();
				Collections.sort(ids);
				StringBuilder sb = new StringBuilder();
				for (String s : ids) {
					sb.append(s + "\n");
				}
				AllBooksWindow.INSTANCE.setData(sb.toString());
				AllBooksWindow.INSTANCE.show();
			}
		});
		/*ALL MEMBER IDS MENU ITEM*/
		MenuItem memberIds = new MenuItem("All Member Id");
		memberIds.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {				
				if (!AddMember.INSTANCE.isInitialized()) {
					AddMember.INSTANCE.init();
				}
				ControllerInterface ci = new SystemController();
				List<String> ids = ci.allMemberIds();
				Collections.sort(ids);
				System.out.println(ids);
				StringBuilder sb = new StringBuilder();
				for (String s : ids) {
					sb.append(s + "\n");
				}
				System.out.println(sb.toString());
				AddMember.INSTANCE.setData(sb.toString());
				AddMember.INSTANCE.show();
			}

		});

		/*ADD BOOK COPY MENU ITEM*/
		MenuItem addCopy = new MenuItem("Add Book Copy");
		addCopy.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				hideAllWindows();
				if (!BookCopyWindow.INSTANCE.isInitialized()) {
					BookCopyWindow.INSTANCE.init();
				}

				BookCopyWindow.INSTANCE.show();
			}
		});

		/*ADD BOOK MENU ITEM*/
		MenuItem addBook = new MenuItem("Add a book");

		addBook.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				hideAllWindows();
				if (!AddBookWindow.INSTANCE.isInitialized()) {
					AddBookWindow.INSTANCE.init();
				}
				AddBookWindow.INSTANCE.show();
			}
		});
		
		//LOGIN AUTHENTATION CONTROL FOR ALL MENU ITEMS
		if (authLevel == Auth.NONE)
			optionsMenu.getItems().addAll(login);
		else if (authLevel == Auth.ADMIN)
			optionsMenu.getItems().addAll(addmember,memberList,  addBook, bookIds, addCopy  );
		else if (authLevel == Auth.LIBRARIAN)
			optionsMenu.getItems().addAll(checkout);
		else
			optionsMenu.getItems().addAll(addmember,memberList, addBook, bookIds, addCopy, checkout);
		
		mainMenu.getMenus().addAll(optionsMenu);
		Scene scene = new Scene(topContainer, 420, 375);
		primaryStage.setScene(scene);
		scene.getStylesheets().add(getClass().getResource("library.css").toExternalForm());
		primaryStage.show();
	}

}

package ui;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class BothWindow extends Stage {
	public static final BothWindow INSTANCE = new BothWindow();

	private BothWindow() {
	}

	private static Stage primStage = null;

	public static Stage primStage() {
		return primStage;
	}

	public static class Colors {
		static Color green = Color.web("#034220");
		static Color red = Color.FIREBRICK;
	}

	public void init() {

		VBox pane = new VBox();
		pane.setPadding(new Insets(100, 100, 100, 100));

		GridPane grid = new GridPane();
		grid.setId("top-container");
		grid.setAlignment(Pos.CENTER);
		grid.setHgap(10);
		grid.setVgap(10);
		grid.setPadding(new Insets(30, 30, 30, 30));

		Button newBooks = new Button("Add New Books");
		grid.add(newBooks, 1, 4);

		Button newMembers = new Button("Create New Members");
		grid.add(newMembers, 1, 8);

		Button checkoutbtn = new Button("Checkout Book");
		grid.add(checkoutbtn, 1, 12);

		pane.getChildren().addAll(grid);

		newBooks.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {

			}
		});
		Scene scene = new Scene(pane);

		scene.getStylesheets().add(getClass().getResource("library.css").toExternalForm());
		setTitle("BOTH");
		setScene(scene);
		show();
	}

}
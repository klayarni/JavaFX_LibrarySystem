package ui;

import java.util.Optional;

import business.Address;
import business.ControllerInterface;
import business.LibraryMember;
import business.SystemController;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import ui.component.OwnAlert;
import ui.component.SubTitle;


public class AddMember extends Stage implements LibWindow {
	public static final AddMember INSTANCE = new AddMember();

	private boolean isInitialized = false;

	public boolean isInitialized() {
		return isInitialized;
	}

	public void isInitialized(boolean val) {
		isInitialized = val;
	}

	private TextArea ta;

	public void setData(String data) {
		ta.setText(data);
	}

	/* This class is a singleton */
	private AddMember() {
	}

	private Button actionBtn;

	public void addMember() {
		actionBtn.setText("Add");
	}

	private TextField firstNameTxtf;
	private TextField lastNameTxtf;
	private TextField streetTxtf;
	private TextField cityTxtf;
	private TextField stateTxtf;
	private TextField zipTxtf;
	private TextField phoneNumberTxtf;
	private Text scenetitle;
	private Text messageBar = new Text();

	public void clearFields() {
		firstNameTxtf.setText("");
		lastNameTxtf.setText("");
		streetTxtf.setText("");
		cityTxtf.setText("");
		stateTxtf.setText("");
		zipTxtf.setText("");
		phoneNumberTxtf.setText("");
	}

	private LibraryMember currentMember;

	public void updateMember(LibraryMember member) {
		this.currentMember = member;
		scenetitle.setText("ID " + member.getMemberId());

		actionBtn.setText("Update");

		firstNameTxtf.setText(member.getFirstName());
		lastNameTxtf.setText(member.getLastName());

		Address address = member.getAddress();

		streetTxtf.setText(address.getStreet());
		cityTxtf.setText(address.getCity());
		stateTxtf.setText(address.getState());
		zipTxtf.setText(address.getZip());
		phoneNumberTxtf.setText(member.getTelephone());

		currentMember = member;
	}

	public void init() {
		VBox vbox = new VBox(5);
		vbox.setPadding(new Insets(25));
		vbox.setId("top-container");

		scenetitle = new SubTitle("Add new member");

		BorderPane topPane = new BorderPane();
		topPane.setCenter(scenetitle);
		topPane.setPadding(new Insets(0, 10, 20, 0));

		Button backBtn = new Button("Back");

		HBox hBack = new HBox(10);
		hBack.setAlignment(Pos.BOTTOM_LEFT);
		hBack.getChildren().add(backBtn);
		topPane.setLeft(hBack);

		GridPane grid = new GridPane();
		grid.setAlignment(Pos.CENTER);
		grid.setHgap(10);
		grid.setVgap(5);
		grid.setPadding(new Insets(25, 25, 25, 25));

		vbox.getChildren().addAll(topPane, grid);

		grid.add(topPane, 0, 0, 2, 1);

		Label firstNameLbl = new Label("First Name: ");
		grid.add(firstNameLbl, 0, 3);
		firstNameTxtf = new TextField();
		grid.add(firstNameTxtf, 1, 3);

		Label lastNameLbl = new Label("Last Name: ");
		grid.add(lastNameLbl, 0, 4);
		lastNameTxtf = new TextField();
		grid.add(lastNameTxtf, 1, 4);

		// Address Section
		Label StreetLbl = new Label("Street: ");
		grid.add(StreetLbl, 0, 7);
		streetTxtf = new TextField();
		grid.add(streetTxtf, 1, 7);

		Label CityLbl = new Label("City: ");
		grid.add(CityLbl, 0, 8);
		cityTxtf = new TextField();
		grid.add(cityTxtf, 1, 8);

		Label StateLbl = new Label("State: ");
		grid.add(StateLbl, 0, 9);
		stateTxtf = new TextField();
		grid.add(stateTxtf, 1, 9);

		Label ZipLbl = new Label("Zip: ");
		grid.add(ZipLbl, 0, 10);
		zipTxtf = new TextField();
		grid.add(zipTxtf, 1, 10);

		// Contact Section
		Label PhoneNumberLbl = new Label("Phone Number: ");
		grid.add(PhoneNumberLbl, 0, 13);
		phoneNumberTxtf = new TextField();
		grid.add(phoneNumberTxtf, 1, 13);

		actionBtn = new Button("Add");
		HBox hbBtn = new HBox(11);
		hbBtn.setAlignment(Pos.BOTTOM_RIGHT);
		hbBtn.getChildren().add(actionBtn);
		grid.add(hbBtn, 1, 15);

		actionBtn.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				String firstNameStr = firstNameTxtf.getText().trim();
				String lastNameStr = lastNameTxtf.getText().trim();
				String streetStr = streetTxtf.getText().trim();
				String cityStr = cityTxtf.getText().trim();
				String stateStr = stateTxtf.getText().trim();
				String zipStr = zipTxtf.getText().trim();
				String phoneNumberStr = phoneNumberTxtf.getText().trim();					
				
				Optional<ButtonType> result;
				
				if (actionBtn.getText().equals("Add")) {
   					
   					result = new OwnAlert(AlertType.CONFIRMATION, "Confirmation", "Are you sure to create a new member?").showAndWait();
   					
   					if (result.get() == ButtonType.OK) {       						
   	            	   ControllerInterface c = new SystemController();       	 
   					
   					c.updateMember(new LibraryMember(currentMember != null ? currentMember.getMemberId() // update
   							: "ST" + (System.currentTimeMillis()/1000), // new
   							firstNameStr, lastNameStr, phoneNumberStr, new Address(streetStr, cityStr, stateStr, zipStr)));			
   	            	   
   	            	   result = new OwnAlert(AlertType.NONE, "Success", "The member is added successful", ButtonType.OK).showAndWait();	       					
   	            	   if (result.get() == ButtonType.OK) {
           					clearFields();
           					Start.showMembers(true);
   	            	   }       	            	   
   					} 
   					
        		} else if (actionBtn.getText().equals("Update")) {
        			        			
        			result = new OwnAlert(AlertType.CONFIRMATION, "Confirmation", "Are you sure to update this memeber").showAndWait();
        			if (result.get() == ButtonType.OK) {
        				 ControllerInterface c = new SystemController();
        				 
        				c.updateMember(new LibraryMember(currentMember != null ? currentMember.getMemberId() // update
       							: "ST" +  (System.currentTimeMillis()/1000), // new
       							firstNameStr, lastNameStr, phoneNumberStr, new Address(streetStr, cityStr, stateStr, zipStr)));	
        				
        				Start.showMembers(true);
        			}
        			
        		}				
			}
		});

		backBtn.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				Start.showMembers(true);
			}
		});
		Scene scene = new Scene(vbox);
		super.setTitle("Member Information");
		setScene(scene);

	}

	public String getFirstNameValue() {
		return firstNameTxtf.getText();
	}

	public String getLastNameValue() {
		return lastNameTxtf.getText();
	}

	public String getStreetValue() {
		return streetTxtf.getText();
	}

	public String getCityValue() {
		return cityTxtf.getText();
	}

	public String getStateValue() {
		return stateTxtf.getText();
	}

	public String getZipValue() {
		return zipTxtf.getText();
	}

	public String getPhoneNumberValue() {
		return phoneNumberTxtf.getText();
	}

	public static AddMember getInstance() {
		return INSTANCE;
	}

}
package ui;

import java.util.List;
import java.util.Optional;
import business.ControllerInterface;
import business.LibraryMember;
import business.SystemController;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Callback;


public class MembersWindow extends Stage implements LibWindow {
	public static final MembersWindow INSTANCE = new MembersWindow();
	private Text scenetitle;
	private boolean isInitialized = false;

	public boolean isInitialized() {
		return isInitialized;
	}

	public void isInitialized(boolean val) {
		isInitialized = val;
	}

	private Text messageBar = new Text();

	public void clear() {
		messageBar.setText("");
	}

	private TableView<LibraryMember> tableView;

	public void setData(List<LibraryMember> data) {
		tableView.setItems(FXCollections.observableList(data));
	}

	/* This class is a singleton */
	private MembersWindow() {
	}

	public void init() {

		super.setTitle("View All Member List");

		BorderPane topPane = new BorderPane();
		topPane.setCenter(scenetitle);
		topPane.setPadding(new Insets(0, 10, 20, 0));				
		

		tableView = new TableView<>();

		TableColumn<LibraryMember, String> column0 = new TableColumn<>("ID");
		column0.setCellValueFactory(new PropertyValueFactory<>("memberId"));

		TableColumn<LibraryMember, String> column1 = new TableColumn<>("First Name");
		column1.setCellValueFactory(new PropertyValueFactory<>("firstName"));

		TableColumn<LibraryMember, String> column2 = new TableColumn<>("Last Name");
		column2.setCellValueFactory(new PropertyValueFactory<>("lastName"));

		TableColumn<LibraryMember, String> column3 = new TableColumn<>("Address");
		column3.setCellValueFactory(new PropertyValueFactory<>("address"));

		TableColumn<LibraryMember, String> column4 = new TableColumn<>("Phone Number");
		column4.setCellValueFactory(new PropertyValueFactory<>("telephone"));

		TableColumn<LibraryMember, String> actionColumn = new TableColumn<>("Action");
		actionColumn.setPrefWidth(300);

		Callback<TableColumn<LibraryMember, String>, TableCell<LibraryMember, String>> cellFactory = new Callback<TableColumn<LibraryMember, String>, TableCell<LibraryMember, String>>() {

			public TableCell<LibraryMember, String> call(TableColumn<LibraryMember, String> arg0) {
				final TableCell<LibraryMember, String> cell = new TableCell<LibraryMember, String>() {

					final Button btnUpdate = new Button("Update");
					final Button btnDelete = new Button("Delete");

					@Override
					public void updateItem(String item, boolean empty) {
						super.updateItem(item, empty);
						if (empty) {
							setGraphic(null);
							setText(null);
						} else {
							HBox hbox = new HBox(5);

							btnUpdate.setOnAction(event -> {
								LibraryMember member = getTableView().getItems().get(getIndex());

								Start.hideAllWindows();
								if (!AddMember.INSTANCE.isInitialized()) {
									AddMember.INSTANCE.init();
								}

								AddMember.INSTANCE.show();
								AddMember.INSTANCE.updateMember(member);

							});

							btnDelete.setOnAction(event -> {
								LibraryMember member = getTableView().getItems().get(getIndex());

								Optional<ButtonType> result = new Alert(AlertType.CONFIRMATION).showAndWait();

								if (result.get() == ButtonType.OK) {
									ControllerInterface c = new SystemController();
									c.deleteMember(member.getMemberId());
									tableView.getItems().remove(getIndex());
								}

							});

							hbox.getChildren().addAll(btnUpdate, btnDelete);

							setGraphic(hbox);
							setText(null);
						}
					}
				};
				return cell;
			}
		};

		actionColumn.setCellFactory(cellFactory);

		tableView.getColumns().add(column0);
		tableView.getColumns().add(column1);
		tableView.getColumns().add(column2);
		tableView.getColumns().add(column3);
		tableView.getColumns().add(column4);
		tableView.getColumns().add(actionColumn);

		VBox vbox1 = new VBox(tableView);
		vbox1.setPadding(new Insets(25));	
		
		Button backBtn = new Button("<= Back to Main");		
		Button addMemberBtn = new Button("Add member");
		vbox1.getChildren().add(addMemberBtn);		
		vbox1.getChildren().add(backBtn);		

		addMemberBtn.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				Start.addMember();
			}
		});
		
		backBtn.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				Start.hideAllWindows();
				Start.primStage().show();
			}
		});
		
		@SuppressWarnings("unused")
		Label firstNameLbl = new Label("Add your Member Here: ");

		Scene scene = new Scene(vbox1);
		setScene(scene);

	}
}

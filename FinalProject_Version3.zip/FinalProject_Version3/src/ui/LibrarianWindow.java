package ui;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class LibrarianWindow extends Stage {
	public static final LibrarianWindow INSTANCE = new LibrarianWindow();

	private LibrarianWindow() {
	}

	Stage primStage = null;

	public Stage primStage() {
		return primStage;
	}

	public static class Colors {
		static Color green = Color.web("#034220");
		static Color red = Color.FIREBRICK;
	}

	public void init() {

		VBox pane = new VBox();
		pane.setPadding(new Insets(100, 100, 100, 100));

		GridPane grid = new GridPane();
		grid.setId("top-container");
		grid.setAlignment(Pos.CENTER);
		grid.setHgap(10);
		grid.setVgap(10);
		grid.setPadding(new Insets(25, 25, 25, 25));

		Button checkoutbtn = new Button("Checkout Book");
		grid.add(checkoutbtn, 1, 4);

		pane.getChildren().addAll(grid);

		checkoutbtn.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {

			}
		});

		Scene scene = new Scene(pane);
		scene.getStylesheets().add(getClass().getResource("library.css").toExternalForm());
		setTitle("Librarian Window");

		setScene(scene);
		show();
	}

}

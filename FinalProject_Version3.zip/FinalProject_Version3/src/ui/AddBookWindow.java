package ui;




import java.util.ArrayList;
import java.util.List;

import business.Author;
import business.Book;
import business.ControllerInterface;
import business.LibrarySystemException;
import business.SystemController;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
/*
 * Eman Sorour
 */
public class AddBookWindow extends Stage implements LibWindow{
	public static final AddBookWindow INSTANCE = new AddBookWindow();

	private boolean isInitialized = false;

	public boolean isInitialized() {
		return isInitialized;
	}
	public void isInitialized(boolean val) {
		isInitialized = val;
	}
	private Text messageBar = new Text();
	public void clear() {
		messageBar.setText("");
	}

	/* This class is a singleton */
	private AddBookWindow() {}

	public void init() { 
		GridPane grid = new GridPane();
		grid.setId("top-container");
		grid.setAlignment(Pos.CENTER);
		grid.setHgap(10);
		grid.setVgap(10);
		grid.setPadding(new Insets(25, 25, 25, 25));

		Text scenetitle = new Text("Add a book");
		scenetitle.setFont(Font.font("Harlow Solid Italic", FontWeight.NORMAL, 20)); //Tahoma
		grid.add(scenetitle, 0, 0, 2, 1);

		Label ISBN = new Label("ISBN :");
		grid.add(ISBN, 0, 1);

		TextField ISBNBox = new TextField();
		grid.add(ISBNBox, 1, 1);

		Label title = new Label("Title :");
		grid.add(title, 0, 2);
		grid.setGridLinesVisible(false) ;

		TextField titleBox = new TextField();
		grid.add(titleBox, 1, 2);



		Label maxLength = new Label("Max Length :");
		grid.add(maxLength, 0, 3);
		grid.setGridLinesVisible(false) ;

		TextField maxLengthBox = new TextField();
		grid.add(maxLengthBox, 1, 3);


		ControllerInterface c = new SystemController();
		ObservableList<Author> authorList =  FXCollections.observableArrayList(c.getAuthors());
		ListView<Author> AuthorlistView = new ListView<Author>();
		AuthorlistView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
		List<Author> selectedItems =  new ArrayList<Author>();
		for (Author author : authorList) {
			AuthorlistView.getItems().add(author);
		}
		for (Author author : authorList) {
			selectedItems.add(author);
		}
		
		Label authors = new Label("Author :");
		grid.add(authors, 0, 4);
		grid.setGridLinesVisible(false) ;

		grid.add(AuthorlistView, 1, 4);


		Button saveBtn = new Button("Save");
		HBox hbBtn = new HBox(10);
		hbBtn.setAlignment(Pos.BOTTOM_RIGHT);
		hbBtn.getChildren().add(saveBtn);
		grid.add(hbBtn, 1, 5);




		saveBtn.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				ControllerInterface c = new SystemController();
				int maxLength = Integer.parseInt(maxLengthBox.getText().trim());
				try {
					c.addBook(new Book(ISBNBox.getText().trim(), titleBox.getText().trim(), maxLength, selectedItems));
				} catch (LibrarySystemException e1) {
					e1.printStackTrace();
				}
			}
		});

		Button backBtn = new Button("<= Back to Main");
		backBtn.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				Start.hideAllWindows();
				Start.primStage().show();
			}
		});
		HBox hBack = new HBox(10);
		hBack.setAlignment(Pos.BOTTOM_LEFT);
		hBack.getChildren().add(backBtn);
		grid.add(hBack, 0, 7);
		Scene scene = new Scene(grid);
		scene.getStylesheets().add(getClass().getResource("library.css").toExternalForm());
		setScene(scene);

	}

}

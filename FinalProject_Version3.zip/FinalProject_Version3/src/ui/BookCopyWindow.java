package ui;

import business.ControllerInterface;
import business.LibrarySystemException;
import business.SystemController;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class BookCopyWindow extends Stage implements LibWindow {
	public static final BookCopyWindow INSTANCE = new BookCopyWindow();

	private boolean isInitialized = false;

	public boolean isInitialized() {
		return isInitialized;
	}

	public void isInitialized(boolean val) {
		isInitialized = val;
	}

	private Text messageBar = new Text();

	public void clear() {
		messageBar.setText("");

	}

	/* This class is a singleton */
	private BookCopyWindow() {
	}

	private TextArea ta;

	public void setData(String data) {
		ta.setText(data);
	}

	public void init() {
		GridPane grid = new GridPane();
		grid.setId("top-container");
		grid.setAlignment(Pos.CENTER);
		grid.setHgap(10);
		grid.setVgap(10);
		grid.setPadding(new Insets(25, 25, 25, 25));

		Text scenetitle = new Text("Add Copy");
		scenetitle.setFont(Font.font("Harlow Solid Italic", FontWeight.NORMAL, 20));
		grid.add(scenetitle, 0, 0, 2, 1);

		Label ISBN = new Label("ISBN :");
		grid.add(ISBN, 0, 1);

		TextField ISBNBox = new TextField();
		grid.add(ISBNBox, 1, 1);

		Label copyNumber = new Label("Copy Number :");
		grid.add(copyNumber, 0, 2);
		grid.setGridLinesVisible(false);

		TextField copyNumberBox = new TextField();
		grid.add(copyNumberBox, 1, 2);

		Button saveBtn = new Button("Save");
		HBox hbBtn = new HBox(10);
		hbBtn.setAlignment(Pos.BOTTOM_RIGHT);
		hbBtn.getChildren().add(saveBtn);
		grid.add(hbBtn, 1, 4);

		HBox messageBox = new HBox(10);
		messageBox.setAlignment(Pos.BOTTOM_RIGHT);
		messageBox.getChildren().add(messageBar);
		grid.add(messageBox, 1, 5);

		saveBtn.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {

				if (!ISBNBox.getText().isEmpty() && !copyNumberBox.getText().isEmpty()) {
					try {
						Integer.parseInt(copyNumberBox.getText().trim());
					} catch (Exception e1) {
						messageBar.setText("Copy number should be number");
						messageBar.setFill(Start.Colors.red);
					}

					try {
						ControllerInterface c = new SystemController();
						try {
							int numOfCopies = Integer.parseInt(copyNumberBox.getText().trim());
							c.addCopy(ISBNBox.getText().trim(), numOfCopies);
							messageBar.setFill(Start.Colors.green);
							messageBar.setText("Copy added successfully");
						} catch (NumberFormatException ex) {
							messageBar.setText("Error! " + ex.getMessage());
							messageBar.setFill(Start.Colors.red);
						}
					}

					catch (LibrarySystemException e2) {
						messageBar.setText("Error! " + e2.getMessage());
						messageBar.setFill(Start.Colors.red);
					}
				}
			}
		});

		Button backBtn = new Button("<= Back to Main");
		backBtn.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				Start.hideAllWindows();
				Start.primStage().show();
			}
		});
		HBox hBack = new HBox(10);
		hBack.setAlignment(Pos.BOTTOM_LEFT);
		hBack.getChildren().add(backBtn);
		grid.add(hBack, 0, 7);
		Scene scene = new Scene(grid);
		scene.getStylesheets().add(getClass().getResource("library.css").toExternalForm());
		setScene(scene);

	}

}

package business;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

import dataaccess.Auth;
import dataaccess.DataAccess;
import dataaccess.DataAccessFacade;
import dataaccess.User;

public class SystemController implements ControllerInterface {
	public static Auth currentAuth = null;
	//LOGIN START 
	public void login(String id, String password) throws LoginException {
		DataAccess da = new DataAccessFacade();
		HashMap<String, User> map = da.readUserMap();
		if(!map.containsKey(id)) {
			throw new LoginException("ID " + id + " not found");
		}
		String passwordFound = map.get(id).getPassword();
		if(!passwordFound.equals(password)) {
			throw new LoginException("Password incorrect");
		}
		currentAuth = map.get(id).getAuthorization();

	}
	//LOGIN END
	
	//BOOK START 
	/*RETRIEVE ALL BOOK ID ONLY FROM DATA ACCESS FACADE */
	@Override
	public List<String> allBookIds() {
		DataAccess da = new DataAccessFacade();
		List<String> retval = new ArrayList<>();
		retval.addAll(da.readBooksMap().keySet());
		return retval;
	}
	
	@Override
	public List<Author> getAuthors() {
	DataAccess da = new DataAccessFacade();
	HashMap<String,Book> retval = da.readBooksMap();
	Collection<Book> books=retval.values();
	List<Author> authorList=new ArrayList<Author>();
	for (Book book : books) {
	authorList.addAll(book.getAuthors());
	}
	System.out.println("List of Authors: " + authorList);
	return authorList;
	}
	// BOOK END
	
	//MEMBER START 
	/*RETRIEVE ALL MEMBER ID ONLY*/
	@Override
	public List<String> allMemberIds() {
		DataAccess da = new DataAccessFacade();
		List<String> retval = new ArrayList<>();
		retval.addAll(da.readMemberMap().keySet());
		return retval;
	}
	/*RETRIEVE ALL LIST OF MEMBERS INFORMATION  */
	@Override
	public List<LibraryMember> allMembers() {
		DataAccess da = new DataAccessFacade();		
		Collection<LibraryMember> members = da.readMemberMap().values();		
		return new ArrayList<LibraryMember>(members);
	}
	/*ADD NEW MEMBER WITH ADDRESS  */
	public void addMember(LibraryMember member) {
		DataAccess da = new DataAccessFacade();
		da.saveNewMember(member);	
	}
	/*DELETE MEMBER FROM THE LIST  */
	@Override
	public void deleteMember(String memberId) {
		DataAccess da = new DataAccessFacade();
		da.deleteMember(memberId);				
	}
	/*UPDATE MEMBER INFORMATION ACCORDING TO MEMBER ID  */
	@Override
	public void updateMember(LibraryMember member) {
		DataAccess da = new DataAccessFacade();
		da.updateMember(member);				
	}
	//MEMBER END

	//BOOK COPY START 
	/*ADD BOOK COPY BY ISBN NUMBER */
	@Override
	public void addCopy(String isbn, int numOfCopies) throws LibrarySystemException {
		
		DataAccess da = new DataAccessFacade();
		HashMap<String,Book> retval = da.readBooksMap();
		Book book = retval.get(isbn);
		if (book == null)
			throw new LibrarySystemException("ISBN " + isbn + " not found");	
		for (int i = 0; i < numOfCopies; i++)
			book.addCopy();
		da.updateBook(book);
		System.out.println("List of Books: ");
		System.out.println(da.readBooksMap());
	}	
	//BOOK COPY END 
	
	//BOOK START 
	/*ADD NEW BOOK  */
	@Override
	public void addBook(Book book) throws LibrarySystemException {
		DataAccess da = new DataAccessFacade();
		da.updateBook(book);
		System.out.println("List of Books: ");
		System.out.println(da.readBooksMap());

	}
	//BOOK END 

	//CHECK OUT START
	/*Get the next available copy number, 
	 * get the next available copy, 
	 * get the length of the checkout, 
	 * checkout a book,
	 * save checkout record,
	 * save book*/
	public void checkout(String memberId, String isbn) throws CheckoutException {
		DataAccess da = new DataAccessFacade();
		HashMap<String, LibraryMember> map = da.readMemberMap();
		HashMap<String,Book> bookMap = da.readBooksMap();
		
		if(!map.containsKey(memberId)) {
			throw new CheckoutException("ID " + memberId + " not found");
		}
		
		if(! bookMap.containsKey(isbn) || ! bookMap.get(isbn).isAvailable()) {
			throw new CheckoutException("Book not found or no copy is available");
		}

		Book book = bookMap.get(isbn);
		LibraryMember member = map.get(memberId);	
		BookCopy nextAvailableCopy = book.getNextAvailableCopy();
		int checkoutLength = book.getMaxCheckoutLength();
		LocalDate outDate = LocalDate.now();
		LocalDate DueDate = outDate.plus(checkoutLength, ChronoUnit.DAYS);	
		CheckoutEntry cout = member.CheckoutEntry(nextAvailableCopy, outDate, DueDate);		
		da.saveNewCheckout(cout);	
		da.updateBook(book);
		System.out.println(bookMap);		
	}
	//CHECK OUT END
}

package business;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

final public class LibraryMember extends Person implements Serializable, Comparable<LibraryMember> {
	private String memberId;
	List<CheckoutEntry> checkout= new ArrayList<>();
	
	///////////////////////////////////EmelyStart
	public List<CheckoutEntry> getCheckout() {
		return checkout;
	}
	public CheckoutEntry CheckoutEntry(BookCopy copy, LocalDate outDate, LocalDate dueDate) {
		//set isavailable to false
		copy.changeAvailability();
		//checkout the book
		CheckoutEntry cout = new CheckoutEntry(this, copy, outDate, dueDate);
		//checkout.add(cout);
		return cout;
		
	}
	///////////////////////////EmelyEnd
	
	public LibraryMember(String memberId, String fname, String lname, String tel,Address add) {
		super(fname,lname, tel, add);
		this.memberId = memberId;		
	}
	
	
	public String getMemberId() {
		return memberId;
	}

	
	
	@Override
	public String toString() {
		return "Member Info: " + "ID: " + memberId + ", name: " + getFirstName() + " " + getLastName() + 
				", " + getTelephone() + " " + getAddress();
	}

	private static final long serialVersionUID = -2226197306790714013L;

	@Override
	public int compareTo(LibraryMember o) {
		return memberId.compareTo(o.getMemberId()) > 0 ? -1 : 1;
	}
	
	
}

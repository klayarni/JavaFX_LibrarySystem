
package business;

import java.io.Serializable;
import java.time.LocalDate;

@SuppressWarnings("serial")
public class CheckoutEntry implements Serializable {
	// private String item;
	private LocalDate date;
	private LocalDate dueDate;
	private LibraryMember libMember;
	private BookCopy copy;
	private CheckoutRecord checkoutReco;

	public CheckoutEntry(LibraryMember libMember, BookCopy copy, LocalDate outDate, LocalDate dueDate2) {		
		this.date = outDate;
		this.dueDate = dueDate2;
		this.libMember = libMember;	
		this.copy = copy;
	}
	
	public LocalDate getDate() {
		return date;
	}

	public LocalDate getDueDate() {
		return dueDate;
	}

	public BookCopy getCopy() {
		return copy;
	}

}

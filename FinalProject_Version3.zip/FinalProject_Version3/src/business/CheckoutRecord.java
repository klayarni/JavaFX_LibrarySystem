package business;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("serial")
public class CheckoutRecord implements Serializable {
	List<CheckoutEntry> checkout = new ArrayList<>();
	private LibraryMember libMember;
	
	public CheckoutRecord() {
	}
	public CheckoutRecord(List<CheckoutEntry> checkout, LibraryMember libMember) {
		this.checkout = checkout;
		this.libMember = libMember;
	}
	public List<CheckoutEntry> getCheckout() {
		return checkout;
	}
	public void setCheckout(List<CheckoutEntry> checkout) {
		this.checkout = checkout;
	}
	public LibraryMember getLibMember() {
		return libMember;
	}
	public void setLibMember(LibraryMember libMember) {
		this.libMember = libMember;
	}
	

}

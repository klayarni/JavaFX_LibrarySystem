package business;

import java.util.List;

public interface ControllerInterface {
	public void login(String id, String password) throws LoginException;	
	public List<Author> getAuthors();
	//MEMBER START
	public List<LibraryMember> allMembers();
	public void addMember(LibraryMember member);
	public void deleteMember(String memberId);
	public void updateMember(LibraryMember member);
	public List<String> allMemberIds();
	//MEMBER END
	
	//CHECKOUT START
	public void checkout(String memberId, String isbn) throws CheckoutException;
	//CHECKOUT END
	
	//BOOK START
	void addBook(Book book) throws LibrarySystemException;
	public List<String> allBookIds();
	//BOOK END
	
	//BOOKCOPY START
	public void addCopy(String isbn, int numOfCopies) throws LibrarySystemException;
	//BOOKCOPY END
	
}

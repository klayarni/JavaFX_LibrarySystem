package dataaccess;

import java.util.HashMap;

import business.Book;
import business.CheckoutEntry;
import business.LibraryMember;

public interface DataAccess { 
	public HashMap<String,User> readUserMap();
	public HashMap<String, LibraryMember> readMemberMap();
	//MEMBER START
	public void saveNewMember(LibraryMember member);
	public void deleteMember(String memberId);
	public void updateMember(LibraryMember member);
	public LibraryMember getMemberById(String memberId);
	//MEMBER END
	
	//BOOK START
	public HashMap<String,Book> readBooksMap();
	public void updateBook(Book book);
	//BOOK END
	
	//CHECKOUT START 
	public HashMap<String, CheckoutEntry> readCheckoutntry();
	public void saveNewCheckout(CheckoutEntry entry);
	//CHECK OUT END

}
